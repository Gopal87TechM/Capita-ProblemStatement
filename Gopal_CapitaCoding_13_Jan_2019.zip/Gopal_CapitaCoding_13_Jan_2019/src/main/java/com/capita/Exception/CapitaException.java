package com.capita.Exception;

/**
 * 
 * @author Gopal
 * Custom exception class
 */
public class CapitaException extends Exception {
	
	private static final long serialVersionUID = 1L;
	
	private String errorMessage;

	public CapitaException(String errorMessage) {
		super();
		this.errorMessage = errorMessage;
	}

	public CapitaException() {
		super();
	}


	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

}
