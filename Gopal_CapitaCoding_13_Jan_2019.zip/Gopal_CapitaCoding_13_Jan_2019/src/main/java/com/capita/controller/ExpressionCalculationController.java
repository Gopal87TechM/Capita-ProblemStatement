package com.capita.controller;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capita.serviceImpl.EvaluateExpressionImpl;


/**
 * 
 * @author Gopal
 * This is starting point of application.
 * Taking inputs from user.   
 * 
 * 
 * 
 * Validation is done for:
 * 1: If we get  ")" in start in anywhere in expression, or "(" as last braces in expression.
 * 2: Opening and closing braces are properly.
 * 3: Every operator adjacent should not be operator.
 * 
 * For validation I had used two stacks ,
 * 1st stack : It stores the operators (except "(" and ")").
 * 2nd stack : It stores only "(" and ")".
 * 
 * In first stack for every even position we will have numbers and in odd we will have operators.
 */
public class ExpressionCalculationController {

	final static Logger logger = Logger.getLogger(ExpressionCalculationController.class);
	
	public static void main(String[] args) throws FileNotFoundException, IOException {
		logger.info("Inside GetMaxArrayLengthController class...");
		
		Scanner input = new Scanner(System.in);
    	
    	
    	System.out.println("Enter number of expression to be evaluated ...");
    	
    	int n = input.nextInt();
    	input.nextLine();
    	
    	String[] expr = new String[n]; 
    	
    	System.out.println("you typed : " + n);
    	System.out.println("Press enter to type new expressions ..");
    	
    	
        for (int i = 0; i < n; i++) {
            expr[i] = input.next();
         }
        
        List<String> exprs = Arrays.asList(expr);
        EvaluateExpressionImpl evl = new EvaluateExpressionImpl();
        Map<Integer,String> output = evl.processExpression(exprs);
        
        for (Map.Entry<Integer, String> entry : output.entrySet()) {
            System.out.println("Case #"+entry.getKey()+" : "+entry.getValue());
        }
        
		logger.info("Ends..");
	}
	
	

}
