package com.capita.controller;

public class Test {

	public static void main(String[] args) {
		String anotherEquation = "6*5^2+3-4/2"; // 85
		System.out.println(computeAnother(anotherEquation));
		//System.out.println(computeAnother1(anotherEquation));
	}

	/*static double computeAnother(String equation) {
		double result = 0.0;
		String noMinus = equation.replace("-", "+-");
		String[] byPluses = noMinus.split("\\+");
		double powerResult = 1.0;
		double divisionResult = 1.0;
		for (String multipl : byPluses) {
			String[] byMultipl = multipl.split("\\*");
			double multiplResult = 1.0;
			for (String operand : byMultipl) {
				if (operand.contains("/") || operand.contains("^")) {
					String[] division = operand.split("\\/");

					for (String div : division) {
						if (div.contains("^")) {
							String[] power = div.split("\\^");
							powerResult = Double.parseDouble(power[0]);
							for (int i = 1; i < power.length; i++) {
								powerResult = Math.pow(powerResult, Double.parseDouble(power[i]));
							}
							divisionResult = powerResult;
						} 
						multiplResult *= divisionResult;
					}
				} else {
					multiplResult *= Double.parseDouble(operand);
				}
			}
			result += multiplResult;
		}
		return result;
	}*/
	
	static double computeAnother(String equation) {
		double result = 0.0;
		String noMinus = equation.replace("-", "+-");
		String[] byPluses = noMinus.split("\\+");

		for (String multipl : byPluses) {
			String[] byMultipl = multipl.split("\\*");
			double multiplResult = 1.0;
			double divident = 1.0;
			
			for (String operand : byMultipl) {
				if (operand.contains("/")) {
					String[] division = operand.split("\\/");
					
					int c = 0;
					for(String power : division) {
						
						double powerRes = 1.0;
						if(power.contains("^")) {
							String[] powerArr = power.split("\\^");
							double powerResult = Double.parseDouble(powerArr[0]);
							for (int i = 1; i < powerArr.length; i++) {
								powerResult = power(powerResult,Double.parseDouble(powerArr[i]));
							}
							powerRes = powerResult;
						}
						else {
							powerRes = Double.parseDouble(power);
						}
						if(c == 0) {
							divident = powerRes;
						}else {
							divident =  divident/powerRes;
						}
						c++;
					}
					multiplResult *= divident;
				} else {
					if(operand.contains("^")) {
						String[] powerArr = operand.split("\\^");
						double powerResult = Double.parseDouble(powerArr[0]);
						for (int i = 1; i < powerArr.length; i++) {
							powerResult = power(powerResult,Double.parseDouble(powerArr[i]));
						}
						multiplResult *= powerResult;
					}else {
						divident = Double.parseDouble(operand);
						multiplResult *= divident;
					}
				}
			}
			result += multiplResult;
		}

		return result;
	}

	static double computeAnother1(String equation) {
		double result = 0.0;
		String noMinus = equation.replace("-", "+-");
		String[] byPluses = noMinus.split("\\+");

		for (String multipl : byPluses) {
			String[] byMultipl = multipl.split("\\*");
			double multiplResult = 1.0;
			for (String operand : byMultipl) {
				if (operand.contains("/")) {
					String[] division = operand.split("\\/");
					double divident = Double.parseDouble(division[0]);
					for (int i = 1; i < division.length; i++) {
						divident /= Double.parseDouble(division[i]);
					}
					multiplResult *= divident;
				} else {
					multiplResult *= Double.parseDouble(operand);
				}
			}
			result += multiplResult;
		}

		return result;
	}
	
	public static double power(double x, double y) {
		return Math.pow(x, y);
	}
}
