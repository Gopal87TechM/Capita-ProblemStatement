package com.capita.service.calculation;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

/**
 * 
 * @author Gopal
 *This class is used to calculate the value to the validated expression.
 */
public class CalculationStack {
	int top = -1;
	int bottom = -1;
	List<String> operatorList;
	List<String> listExpr;
	int countLit = 0;
	String[] a;
	
	CalculationStack(List<String> operatorList,List<String> listExpr){
		this.operatorList = operatorList;
		a = new String[listExpr.size() + 1];
		this.listExpr = listExpr;
	}
	
	
	
	public List<String> push(String literal, boolean isLastChar) {
		countLit++;
		a[++top] = literal;
		bottom = top;
		List<String> listLit = null;
		if(literal.equals(")")) {
			listLit = new LinkedList<String>();
			while(!a[bottom].equals("(")) {
				listLit.add(a[bottom]);
				bottom--;
				a[top] = null;
				top--;
			}
			
			top--;
			bottom--;
			listLit.add("(");
			Collections.reverse(listLit);
		}
		if(isLastChar && !checkIfHasBraces(a)) {
			listLit = convertArrayToList(a);
			listLit.add("==");
		}
		return listLit ;
	}
	
	public int pop() {
		a[top--] = null;
		return top;
	}
	
	public int size() {
		int count = 0;
		for (int i = 0; i < a.length; i++) {
			if(a[i] != null) {
				count++;
			}
		}
		return count;
	}
	
	
	public boolean checkIfHasBraces(String[] stack) {
		boolean flag =false;
		for (int i = 0; i < stack.length; i++) {
			if(null != stack[i] && (stack[i].equals(")") || stack[i].equals("("))) {
				flag = true;
			}
		}
		return flag;
	}
	
	
	public List<String> convertArrayToList(String[] str){
		List<String> list = new LinkedList<String>();
		
		for (int i = 0; i < str.length; i++) {
			if(str[i] != null) {
				list.add(str[i]);
			}
		}
		return list;
	}
}
