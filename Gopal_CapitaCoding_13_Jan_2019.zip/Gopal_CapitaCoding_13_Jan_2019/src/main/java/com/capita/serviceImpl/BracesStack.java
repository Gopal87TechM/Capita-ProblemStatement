package com.capita.serviceImpl;

/**
 * 
 * @author Gopal
 * This class is used to validate the ( and ) inputs in string.
 */
public class BracesStack {
	int top = -1;
	int size = 0;
	String[] a = null;
	
	BracesStack(int exprListLen){
		this.size = exprListLen;
		a = new String[size+1];
	}
	
	/**
	 * 
	 * @param x
	 * At point of time when top is at 0th index then we can not have ).
	 * This is invalid expression having ) at braces in anywhere in string.
	 * 
	 * We are adding only ( braces in stack. If we get any ) we simply remove top most element and do top--.
	 */
	public boolean push(String x) {
		boolean flag = false;
		a[++top] = x;
		
		if(top == 0) {
			if(a[top].equals(")")) {
				flag = false;
				return flag;
			}else {
				flag = true;
			}
		}
		else if(top > 0) {
			flag = true;
			if(a[top].equals(")")) {
				a[top] = null;
				a[top-1] = null;
				top = top -2;
			}
		}
		
		return flag;
	}
	
	public int pop() {
		a[top--] = null;
		return top;
	}
	
	public int size() {
		int count = 0;
		for (int i = 0; i < a.length; i++) {
			if(a[i] != null) {
				count++;
			}
		}
		return count;
	}
}
