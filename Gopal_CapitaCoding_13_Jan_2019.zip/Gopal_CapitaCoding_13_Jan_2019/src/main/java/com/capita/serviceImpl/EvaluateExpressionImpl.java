package com.capita.serviceImpl;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.capita.service.EvaluateExpression;
import com.capita.service.calculation.CalculateExpressionValueService;

/**
 * 
 * @author Gopal
 * This class is for evaluating the expression list passed from console.
 */
public class EvaluateExpressionImpl implements EvaluateExpression {

	private static final String PLUS = "+";
	private static final String SUB = "-";
	private static final String DIV = "/";
	private static final String MUL = "*";
	private static final String POW = "^";
	private static final String OPEN_BRACES = "(";
	private static final String CLOSE_BRACES = ")";

	private static final String ZERO = "0";
	private static final String ONE = "1";
	private static final String TWO = "2";
	private static final String THREE = "3";
	private static final String FOUR = "4";
	private static final String FIVE = "5";
	private static final String SIX = "6";
	private static final String SEVEN = "7";
	private static final String EIGHT = "8";
	private static final String NINE = "9";
	
	private static List<String> listDigit = new ArrayList<String>();
	private static List<String> listOperators = new ArrayList<String>();

	
	/**
	 * Calculating expression list one by one.
	 * Returning Map<Integer,String> where string is the result of expression. 
	 */
	public Map<Integer, String> processExpression(List<String> exprs) {
		Map<Integer, String> output = new LinkedHashMap<Integer, String>();
		int i = 0;
		for(String expr : exprs) {
			i++;
			output.put(i, processSingleExpression(expr));
		}
		return output;
	}

	
	/**
	 * 
	 * @param expr : Single expression
	 * @return : Expression result
	 */
	public String processSingleExpression(String expr) {
		String result = "";
		EvaluateExpressionImpl e = new EvaluateExpressionImpl();
		e.populateList();
		
		List<String> listLiterals = e.convertToList(expr);
		
		/**
		 * Validating the expression
		 */
		boolean validExpr = e.validateExpression(listLiterals);
		
		/**
		 * Evaluating the expression
		 */
		try {
			if(validExpr) {
				CalculateExpressionValueService calExprSer = new CalculateExpressionValueService(listDigit, listOperators,listLiterals);
				double value = calExprSer.calcuateExprValue(listLiterals);
				result = value+"";
			}else {
				result = "INVALID EXPRESSION";
			}
		}catch(NumberFormatException ne) {
			result = "Could not evaluate";
		}
		return result;
	}
	
	/*public static void main(String[] args) {
		String result = "";
		EvaluateExpressionImpl e = new EvaluateExpressionImpl();
		e.populateList();
		String expr = "8*+7";
		List<String> listLiterals = e.convertToList(expr);
		
		*//**
		 * Validating the expression
		 *//*
		boolean validExpr = e.validateExpression(listLiterals);
		
		*//**
		 * Evaluating the expression
		 *//*
		try {
			if(validExpr) {
				CalculateExpressionValueService calExprSer = new CalculateExpressionValueService(listDigit, listOperators,listLiterals);
				double value = calExprSer.calcuateExprValue(listLiterals);
				result = value+"";
			}else {
				result = "INVALID EXPRESSION";
			}
		}catch(NumberFormatException ne) {
			result = "Could not evaluate";
		}
		System.out.println(result);
	}*/
	/**
	 * Creating two list 
	 * 1:Digits list
	 * 2:Operator list
	 */
	public void populateList() {
		listOperators.add(EvaluateExpressionImpl.PLUS);
		listOperators.add(EvaluateExpressionImpl.SUB);
		listOperators.add(EvaluateExpressionImpl.DIV);
		listOperators.add(EvaluateExpressionImpl.MUL);
		listOperators.add(EvaluateExpressionImpl.POW);
		listOperators.add(EvaluateExpressionImpl.OPEN_BRACES);
		listOperators.add(EvaluateExpressionImpl.CLOSE_BRACES);

		listDigit.add(EvaluateExpressionImpl.ZERO);
		listDigit.add(EvaluateExpressionImpl.ONE);
		listDigit.add(EvaluateExpressionImpl.TWO);
		listDigit.add(EvaluateExpressionImpl.THREE);
		listDigit.add(EvaluateExpressionImpl.FOUR);
		listDigit.add(EvaluateExpressionImpl.FIVE);
		listDigit.add(EvaluateExpressionImpl.SIX);
		listDigit.add(EvaluateExpressionImpl.SEVEN);
		listDigit.add(EvaluateExpressionImpl.EIGHT);
		listDigit.add(EvaluateExpressionImpl.NINE);

	}
	
	/**
	 * 
	 * @param expr : Single expression
	 * @return : Converted to list of string.This list will have digits and operators.
	 */
	public List<String> convertToList(String expr) {
		List<String> literals = new LinkedList<String>();
		String expr1 = expr.trim();
		StringBuffer sb = new StringBuffer("");
		for (int i = 0; i < expr1.length(); i++) {
			String temp = expr.charAt(i)+"";
			if(listOperators.contains(temp) || i == expr.length()-1) {
				if(sb.toString().length() > 0) {
					literals.add(sb.toString());
				}
				if(temp.length() > 0) {
					literals.add(temp);
				}
				sb = new StringBuffer("");
				
			}else if(listDigit.contains(temp)) {
				sb = sb.append(temp);
			}
			
		}
		return literals;
	}
	
	/**
	 * 
	 * @param expList : Single expression in list format
	 * @return : If it is valid then return true else false.
	 */
	public boolean validateExpression(List<String> expList) {
		
		ExpressionStack exprSt = new ExpressionStack(expList.size(),listOperators, listDigit);
		
		boolean validExpr = false;
		
		for(String litral : expList) {
			validExpr = exprSt.push(litral);
			if(!validExpr) {
				return validExpr;
			}
		}
		int bracesStackSize = exprSt.size();
		if(bracesStackSize == 0) {
			validExpr = true;
		}
		return validExpr;
	}
}
