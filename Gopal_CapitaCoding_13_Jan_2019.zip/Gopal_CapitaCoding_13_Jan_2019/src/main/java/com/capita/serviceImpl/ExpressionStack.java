package com.capita.serviceImpl;

import java.util.List;
/**
 *This class is used for operators excluding "(" and ")" and digits. 
 */
public class ExpressionStack {
	int top = -1;
	int tempTop = -1;
	int size;
	String[] a = null;
	List<String> listOperators;
	List<String> listDigits;

	BracesStack bracesSt;

	ExpressionStack(int exprListLen, List<String> listOperators, List<String> listDigits) {
		this.size = exprListLen;
		this.listOperators = listOperators;
		this.listDigits = listDigits;
		a = new String[size + 1];
		bracesSt = new BracesStack(listOperators.size());
	}

	public boolean push(String x) {
		boolean flag = false;
		boolean bracesStackFlag = false;
		a[++top] = x;
		if (top == 0) {
			if (a[top].equals("(") || a[top].equals(")")) {
				bracesStackFlag = bracesSt.push(a[top]);
				if(!bracesStackFlag) {
					return bracesStackFlag;
				}
				a[top] = null;
				top--;
			}
			flag = true;
		} else if (top > 0) {
			tempTop++;

			if (a[top].equals("(")) {
				if (listOperators.contains(a[tempTop])) {
					flag = true;
				} else {
					return false;
				}
				bracesStackFlag = bracesSt.push(a[top]);
				if(!bracesStackFlag) {
					return bracesStackFlag;
				}
				a[top] = null;
				top--;
				tempTop--;
			}

			else if (a[top].equals(")")) {
				int num;
				try {
					num = Integer.parseInt(a[tempTop]);
					flag = true;
				} catch (NumberFormatException e) {
					return false;
				} catch (NullPointerException e) {
					return false;
				}
				
				bracesStackFlag = bracesSt.push(a[top]);
				if(!bracesStackFlag) {
					return bracesStackFlag;
				}
				a[top] = null;
				top--;
				tempTop--;
			}
			
			else if(listOperators.contains(a[top])) {
				int num;
				try {
					num = Integer.parseInt(a[tempTop]);
					flag = true;
				} catch (NumberFormatException e) {
					return false;
				} catch (NullPointerException e) {
					return false;
				}
			}
			
			else if(Integer.MIN_VALUE < Integer.parseInt(a[top]) || Integer.parseInt(a[top]) < Integer.MAX_VALUE) {
				if(listOperators.contains(a[tempTop])) {
					flag = true;
				}
			}

		}

		return flag;
	}

	public int pop() {
		a[top--] = null;
		return top;
	}

	public int size() {
		return bracesSt.size();
	}
}
