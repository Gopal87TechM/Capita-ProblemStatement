package com.capita.junit;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

/**
 * 
 * @author Gopal
 * Class to run  all test cases of TestCalculateMaxLenService 
 */
public class TestRunner {
	public static void main(String[] args) {
	      Result result = JUnitCore.runClasses(TestCalculateMaxLenService.class);
			
	      for (Failure failure : result.getFailures()) {
	         System.out.println(failure.toString());
	      }
			
	      System.out.println(result.wasSuccessful());
	   }
}
